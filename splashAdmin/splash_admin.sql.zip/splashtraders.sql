-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2020 at 11:16 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `splashtraders`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `complaint` varchar(255) NOT NULL,
  `complaint_receiving_date` date NOT NULL,
  `complaint_date` date NOT NULL,
  `activity_status` varchar(255) NOT NULL,
  `automatic_serial_number` int(200) NOT NULL,
  `report` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `name`, `address`, `contact`, `complaint`, `complaint_receiving_date`, `complaint_date`, `activity_status`, `automatic_serial_number`, `report`) VALUES
(1, 'arun', 'madurai', '8765432134', 'hi', '2020-01-18', '2020-01-18', 'product 1', 123, 'hi'),
(2, 'prasanna', 'madurai', '8765432134', 'hi', '2020-01-18', '2020-01-18', 'product 1', 123, 'hi'),
(3, 'arun', 'madurai', '8765432134', 'hi', '2020-01-19', '2020-01-19', 'product 1', 123, 'hi'),
(4, 'krishna', 'madurai', '8667859804', 'hello', '2020-01-19', '2020-01-19', 'product 1', 123, 'hi'),
(5, 'jack', 'chennai', '8667859804', 'hi', '2020-01-19', '2020-01-19', 'Sales', 123, 'hi'),
(6, 'john', 'delhi', '8765432134', 'hi', '2020-01-19', '2020-01-19', 'Sales', 321, 'hi'),
(7, 'cena', 'delhi', '8765432134', 'hi', '2020-01-19', '2020-01-19', 'Sales', 456, 'hi'),
(8, 'yoges', 'madurai', '8765432134', 'hi', '2020-01-19', '2020-01-19', 'Sales', 321, 'hi'),
(9, 'kingson', 'delhi', '8667859804', 'hi', '2020-01-19', '2020-01-19', 'Sales', 456, 'hi'),
(10, 'randy', 'madurai', '8765432134', 'hello', '2020-01-19', '2020-01-19', 'Sales', 321, 'hi'),
(11, 'vishal', 'madurai', '8765432134', 'hello', '2020-01-19', '2020-01-19', 'Service', 123, 'hi'),
(12, 'mathan', 'madurai', '8765432134', 'hi', '2020-01-19', '2020-01-19', 'Sales', 123, 'hi'),
(13, 'ambrish', 'madurai', '8765432134', 'hi', '2020-01-19', '2020-01-19', 'Service', 123, 'hi'),
(14, 'venkat', 'delhi', '8667859804', 'hi', '2020-01-19', '2020-01-19', 'Sales', 321, 'hi');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(10) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `sales_person_name` varchar(100) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `customer_email_id` varchar(250) NOT NULL,
  `customer_contact_number` varchar(30) NOT NULL,
  `customer_serial_number` varchar(200) NOT NULL,
  `billing_date` date NOT NULL,
  `paid_amount` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `product_name`, `sales_person_name`, `customer_name`, `customer_email_id`, `customer_contact_number`, `customer_serial_number`, `billing_date`, `paid_amount`) VALUES
(1, 'product', 'product 1', 'satti', 'satii020@gmail.com', '8754927639', '12345', '2020-01-01', 2000),
(2, 'product 1', 'product 2', 'arun', 'arun020@gmail.com', '8754927639', '12345', '2020-01-01', 3000),
(3, 'product 1', 'product 2', 'satti', 'satii020@gmail.com', '8754927639', '12345', '2020-01-19', 5000),
(4, 'Sales', 'Sales', 'yoges', 'yoges907', '8754927639', '12345', '2020-01-19', 3456),
(5, 'Sales', 'Service', 'king', 'king45', '8754927639', '12345', '2020-01-19', 6789),
(6, 'Sales', 'Sales', 'john', 'john20', '8754927639', '12345', '2020-01-19', 3456),
(7, 'Service', 'Service', 'ananthan', 'ananthan127', '8754927639', '12345', '2020-01-19', 7654),
(8, 'Sales', 'Sales', 'arun', 'arun23', '8754927639', '12345', '2020-01-19', 5432),
(9, 'Sales', 'Sales', 'jack', 'jack45', '8754927639', '12345', '2020-01-19', 8978),
(10, 'Sales', 'Sales', 'randy', 'randy45', '8754927639', '12345', '2020-01-19', 1001),
(11, 'Sales', 'Sales', 'orton', 'orton34', '8667859804', '12345', '2020-01-19', 8765),
(12, 'Sales', 'Sales', 'prasanna', 'prasanna37', '908765344', '09876', '2020-01-19', 5678),
(13, 'Sales', 'Sales', 'mani', 'mani90', '908765344', '09876', '2020-01-04', 9876),
(14, 'Sales', 'Sales', 'pink', 'pink98', '908765344', '56789', '2020-01-10', 4567),
(15, 'Sales', 'Sales', 'brock', 'brock23', '908765344', '09876', '2020-01-25', 1235);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(40) NOT NULL,
  `service_type` varchar(255) NOT NULL,
  `staff_id` int(200) NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `activity_status` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `service_type`, `staff_id`, `staff_name`, `activity_status`, `comments`) VALUES
(1, 'product 1', 12345, 'prassana', 'product', 'finished'),
(2, 'Sales', 100, 'yoges', 'Sales', 'completed'),
(3, 'Service', 101, 'ananthan', 'Sales', 'average'),
(4, 'Sales', 102, 'kishore', 'Sales', 'hi'),
(5, 'Sales', 105, 'jack', 'Sales', 'hello'),
(6, 'Sales', 106, 'randy', 'Service', 'hi'),
(7, 'Service', 109, 'orton', 'Sales', 'hello'),
(8, 'Sales', 56, 'brock', 'Sales', 'hi'),
(9, 'Sales', 67, 'cena', 'Sales', 'welcome'),
(10, 'Sales', 65, 'john', 'Service', 'hi'),
(11, 'Sales', 43, 'krish', 'Sales', 'hi'),
(12, 'Sales', 23, 'krishna', 'Sales', 'hi'),
(13, 'Service', 22, 'siva', 'Sales', 'hi'),
(14, 'Sales', 34, 'mani', 'Sales', 'hi'),
(15, 'Sales', 12, 'arun', 'Sales', 'hi');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(30) NOT NULL,
  `category` varchar(20) NOT NULL,
  `user_email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `user_name`, `password`, `category`, `user_email`) VALUES
(9, 'king', 'king', '12345', 'Sales', 'ckananth020'),
(10, 'siva', 'siva', '56789', 'Sales', 'siva20'),
(12, 'sakthi', 'sakthi', '12345', 'Service', 'sakthi010'),
(13, 'kannan', 'kannan', '45678', 'Service', 'kanan010'),
(14, 'ranjith', 'ranjith', '12345', 'Sales', 'ranjith56'),
(15, 'aravind', 'aravind', '12345', 'Service', 'aravind23'),
(16, 'avin', 'avin', '12345', 'Sales', 'avin90'),
(17, 'prasanna', 'prasanna', '23456', 'Sales', 'prasanna78'),
(18, 'mathan', 'mathan', '34567', 'Sales', 'mathan65'),
(19, 'mani', 'mani', '56789', 'Sales', 'mani87'),
(20, 'jack', 'jack', '23456', 'Sales', 'jack65'),
(21, 'john', 'john', '7689', 'Sales', 'john90'),
(22, 'randy', 'randy', '46578', 'Sales', 'randy101'),
(23, 'kishore', 'kishore', '67890', 'Sales', 'kishore45'),
(25, 'cens', 'cena', '78654', 'Sales', 'cena76');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
